export const handler = async (event) => {
  event.Records.forEach((record) => {
    console.log("message attributes ", record.messageAttributes);
    const payload = JSON.parse(record.body);
    console.log("Processing webhook's payload: ", payload.body);
  });
  console.log(event);
  const response = {
    statusCode: 200,
    body: JSON.stringify("webhook processed"),
  };
  return response;
};
